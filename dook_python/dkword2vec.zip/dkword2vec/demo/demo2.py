# -*- coding: UTF-8 -*-
temp=None
if temp is None:
    print("hello")
else:
    print("hello 2")



# 示例1